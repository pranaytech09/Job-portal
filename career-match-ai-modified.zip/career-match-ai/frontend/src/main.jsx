const { useState, useEffect } = window.React;
const { createRoot } = window.ReactDOM;

const PIPELINE_STEPS = [
  "Resume", "Job Search", "URL Validation", "Remove Invalid",
  "Deduplication", "Skill Extraction", "Job Matching",
  "Match Score", "Job Ranking", "Original URL",
  "Skill Gap", "Trending Tech", "Roadmap"
];

const css = {
  page:{minHeight:"100vh",background:"#f5f7fb",color:"#172033",fontFamily:"Arial, sans-serif"},
  header:{background:"#101828",color:"#fff",padding:"20px 28px",display:"flex",justifyContent:"space-between",gap:20,alignItems:"center",flexWrap:"wrap"},
  brand:{display:"flex",gap:12,alignItems:"center"},
  logo:{width:42,height:42,borderRadius:10,background:"#4f46e5",display:"grid",placeItems:"center",fontWeight:800,fontSize:20},
  title:{margin:0,fontSize:24},sub:{margin:"4px 0 0",color:"#aeb8c8",fontSize:13},
  nav:{display:"flex",gap:8,flexWrap:"wrap",padding:"14px 28px",background:"#fff",borderBottom:"1px solid #e5e7eb"},
  navBtn:(active)=>({border:0,borderRadius:8,padding:"9px 14px",cursor:"pointer",background:active?"#4f46e5":"#f1f3f7",color:active?"#fff":"#344054",fontWeight:700}),
  wrap:{maxWidth:1250,margin:"0 auto",padding:24},
  grid:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18},
  card:{background:"#fff",border:"1px solid #e5e7eb",borderRadius:14,padding:20,boxShadow:"0 2px 8px rgba(16,24,40,.04)"},
  h2:{margin:"0 0 8px",fontSize:18},muted:{color:"#667085",fontSize:13},
  label:{display:"block",fontWeight:700,fontSize:13,margin:"14px 0 6px"},
  input:{width:"100%",boxSizing:"border-box",padding:"11px 12px",border:"1px solid #d0d5dd",borderRadius:8,fontSize:14},
  textarea:{width:"100%",boxSizing:"border-box",minHeight:180,padding:12,border:"1px solid #d0d5dd",borderRadius:8,resize:"vertical",fontSize:13},
  primary:{border:0,borderRadius:9,padding:"11px 18px",background:"#4f46e5",color:"#fff",fontWeight:800,cursor:"pointer"},
  secondary:{border:"1px solid #d0d5dd",borderRadius:8,padding:"9px 12px",background:"#fff",cursor:"pointer"},
  chip:{display:"inline-block",padding:"5px 9px",margin:"3px",borderRadius:999,background:"#eef2ff",color:"#3730a3",fontSize:12,fontWeight:700},
  metric:{background:"#f8fafc",border:"1px solid #e5e7eb",borderRadius:10,padding:14},
  metricNum:{fontSize:25,fontWeight:800},
  job:{borderTop:"1px solid #eaecf0",padding:"15px 0"},
};

function App(){
  const [tab,setTab]=useState("analysis");
  const [resumeText,setResumeText]=useState("");
  const [resumeFile,setResumeFile]=useState(null);
  const [targetRole,setTargetRole]=useState("Full Stack Software Engineer");
  const [location,setLocation]=useState("Remote");
  const [loading,setLoading]=useState(false);
  const [step,setStep]=useState(0);
  const [error,setError]=useState("");

  const [profile,setProfile]=useState(null);
  const [jobs,setJobs]=useState([]);
  const [audit,setAudit]=useState(null);
  const [gap,setGap]=useState(null);
  const [trending,setTrending]=useState([]);
  const [roadmap,setRoadmap]=useState(null);
  const [graph,setGraph]=useState(null);

  const [whatIfSkill,setWhatIfSkill]=useState("Docker");
  const [whatIf,setWhatIf]=useState(null);
  const [whatIfLoading,setWhatIfLoading]=useState(false);

  const [samples,setSamples]=useState([]);

  useEffect(()=>{
    fetch("/api/jobs/sample-resumes")
      .then(r=>r.json())
      .then(d=>setSamples(d.resumes || []))
      .catch(()=>{});
  },[]);

  const loadSample=(s)=>{
    setResumeFile(null);
    setResumeText(`${s.name}\nSkills: ${s.skills.join(", ")}\nExperience: ${s.experience} years\nB.Tech Computer Science`);
  };

  const runPipeline=async()=>{
    if(!resumeFile && !resumeText.trim()){
      setError("Upload a resume or paste resume text first.");
      return;
    }

    setError("");
    setLoading(true);
    setWhatIf(null);
    setStep(1);

    const timer=setInterval(()=>setStep(x=>Math.min(x+1,13)),220);

    try{
      const fd=new FormData();

      if(resumeFile){
        fd.append("resume",resumeFile);
      }else{
        const blob=new Blob([resumeText],{type:"text/plain"});
        fd.append("resume",blob,"resume.txt");
      }

      fd.append("target_role",targetRole);
      fd.append("location",location);
      fd.append("sources","Jobvetta,Adzuna,The Muse");

      const response=await fetch("/api/career/pipeline",{method:"POST",body:fd});
      const data=await response.json();

      if(!response.ok) throw new Error(data.detail || "Pipeline failed");

      setProfile(data.candidate_profile);
      setAudit(data.validation_audit);
      setJobs(data.ranked_jobs || []);
      setGap(data.skill_gap_analysis);
      setTrending(data.trending_technologies || []);
      setRoadmap(data.career_roadmap);
      setGraph(data.career_graph || null);
      setTab("analysis");
    }catch(e){
      setError(e.message || "Network error. Make sure FastAPI is running.");
    }finally{
      clearInterval(timer);
      setStep(13);
      setLoading(false);
    }
  };

  const runWhatIf=async()=>{
    if(!profile){setError("Run CareerMatch analysis first.");return;}
    if(!whatIfSkill.trim())return;

    setError("");
    setWhatIfLoading(true);

    try{
      const fd=new FormData();
      const text=resumeText || `${profile.name}\nSkills: ${profile.skills.join(", ")}`;
      const blob=resumeFile || new Blob([text],{type:"text/plain"});
      fd.append("resume",blob,resumeFile?.name || "resume.txt");
      fd.append("target_role",targetRole);
      fd.append("new_skill",whatIfSkill.trim());

      const response=await fetch("/api/career/what-if",{method:"POST",body:fd});
      const data=await response.json();

      if(!response.ok) throw new Error(data.detail || "What-if simulation failed");
      setWhatIf(data);
      setTab("whatif");
    }catch(e){
      setError(e.message || "What-if simulation failed.");
    }finally{
      setWhatIfLoading(false);
    }
  };

  const metric=(label,value)=>{
    return <div style={css.metric}><div style={css.muted}>{label}</div><div style={css.metricNum}>{value}</div></div>;
  };

  const Graph=({data,whatIfData})=>{
    const g=whatIfData?.updated_career_graph || data;
    if(!g)return <div style={css.muted}>Run an analysis to generate your career graph.</div>;

    const skills=(g.nodes||[]).filter(n=>n.type==="skill");
    const missing=(g.nodes||[]).filter(n=>n.type==="missing");
    const future=(g.nodes||[]).filter(n=>n.type==="future");
    const career=(g.nodes||[]).find(n=>n.type==="career");

    return <div style={{padding:"15px 5px"}}>
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:12}}>
        <div style={{padding:"12px 20px",borderRadius:12,background:"#4f46e5",color:"#fff",fontWeight:800}}>
          👤 Your Profile
        </div>
        <div style={{color:"#98a2b3"}}>↓</div>

        <div style={{display:"flex",flexWrap:"wrap",justifyContent:"center",gap:8}}>
          {skills.map(n=><span key={n.id} style={{...css.chip,background:"#ecfdf3",color:"#027a48"}}>{n.label}</span>)}
        </div>

        <div style={{color:"#98a2b3"}}>↓</div>

        <div style={{padding:"13px 22px",borderRadius:12,background:"#111827",color:"#fff",fontWeight:800}}>
          🎯 {career?.label || targetRole}
        </div>

        {missing.length>0 && <>
          <div style={{color:"#98a2b3"}}>↑ Skills to unlock this path</div>
          <div style={{display:"flex",flexWrap:"wrap",justifyContent:"center",gap:8}}>
            {missing.map(n=><span key={n.id} style={{...css.chip,background:"#fff1f2",color:"#be123c"}}>＋ {n.label}</span>)}
          </div>
        </>}

        <div style={{color:"#98a2b3"}}>↓</div>

        <div style={{display:"flex",flexWrap:"wrap",justifyContent:"center",gap:10}}>
          {future.map(n=><div key={n.id} style={{padding:"11px 15px",border:"1px solid #c7d2fe",borderRadius:10,background:"#eef2ff",fontWeight:700}}>{n.label}</div>)}
        </div>
      </div>
    </div>;
  };

  return <div style={css.page}>
    <header style={css.header}>
      <div style={css.brand}>
        <div style={css.logo}>CM</div>
        <div>
          <h1 style={css.title}>CareerMatch AI</h1>
          <p style={css.sub}>Resume → Career Graph → What-if Simulation → Jobs → Roadmap</p>
        </div>
      </div>
      <div style={{fontSize:13,color:"#aeb8c8"}}>AI Career Intelligence Platform</div>
    </header>

    <div style={css.nav}>
      {[
        ["analysis","Analysis"],["jobs","Matched Jobs"],["graph","Career Graph"],
        ["whatif","What-if Simulation"],["roadmap","Roadmap"]
      ].map(([id,label])=>
        <button key={id} style={css.navBtn(tab===id)} onClick={()=>setTab(id)}>{label}</button>
      )}
    </div>

    <main style={css.wrap}>
      {error && <div style={{background:"#fff1f2",border:"1px solid #fecdd3",color:"#be123c",padding:12,borderRadius:9,marginBottom:16}}>{error}</div>}

      {!profile && <div style={{...css.card,marginBottom:18}}>
        <h2 style={css.h2}>Start CareerMatch AI</h2>
        <p style={css.muted}>Upload your resume, analyze your current market position and generate a career path.</p>
      </div>}

      <div style={css.grid}>
        <div style={css.card}>
          <h2 style={css.h2}>📄 Candidate Resume</h2>
          <p style={css.muted}>PDF, DOCX or TXT. You can also paste resume text.</p>

          <label style={css.label}>Upload Resume</label>
          <input type="file" accept=".pdf,.docx,.txt" onChange={e=>setResumeFile(e.target.files?.[0]||null)} />

          <label style={css.label}>Resume Text</label>
          <textarea style={css.textarea} value={resumeText} onChange={e=>{setResumeText(e.target.value);setResumeFile(null)}} placeholder="Paste your resume here..." />

          {samples.length>0 && <div style={{marginTop:10}}>
            <div style={css.muted}>Quick demo resumes:</div>
            <div style={{display:"flex",gap:7,flexWrap:"wrap",marginTop:7}}>
              {samples.map(s=><button key={s.id} style={css.secondary} onClick={()=>loadSample(s)}>{s.name}</button>)}
            </div>
          </div>}
        </div>

        <div style={css.card}>
          <h2 style={css.h2}>🎯 Career Target</h2>
          <p style={css.muted}>Choose the role you want the system to evaluate.</p>

          <label style={css.label}>Target Role</label>
          <input style={css.input} value={targetRole} onChange={e=>setTargetRole(e.target.value)} />

          <label style={css.label}>Preferred Location</label>
          <input style={css.input} value={location} onChange={e=>setLocation(e.target.value)} />

          <button style={{...css.primary,marginTop:18,width:"100%"}} disabled={loading} onClick={runPipeline}>
            {loading ? `Analyzing... ${step}/13` : "🚀 Run CareerMatch AI"}
          </button>

          {loading && <div style={{marginTop:14}}>
            <div style={{height:7,background:"#e5e7eb",borderRadius:99}}>
              <div style={{height:7,width:`${(step/13)*100}%`,background:"#4f46e5",borderRadius:99}} />
            </div>
            <p style={css.muted}>Step {step}: {PIPELINE_STEPS[step-1] || "Complete"}</p>
          </div>}
        </div>
      </div>

      {profile && <div style={{...css.card,marginTop:18}}>
        <h2 style={css.h2}>👤 Career Profile</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
          {metric("Candidate",profile.name)}
          {metric("Experience",`${profile.years_of_experience || 0} yrs`)}
          {metric("Skills",profile.skills?.length || 0)}
          {metric("Market Readiness",`${gap?.market_readiness_index || 0}%`)}
        </div>
        <div style={{marginTop:12}}>
          {(profile.skills||[]).map(s=><span key={s} style={css.chip}>{s}</span>)}
        </div>
      </div>}

      {tab==="analysis" && profile && <div style={{marginTop:18,display:"grid",gridTemplateColumns:"1fr 1fr",gap:18}}>
        <div style={css.card}>
          <h2 style={css.h2}>📊 Market Analysis</h2>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {metric("Jobs Analyzed",jobs.length)}
            {metric("Critical Gaps",gap?.critical_gaps_count || 0)}
            {metric("Top Match",jobs[0]?.match_score ? `${jobs[0].match_score}%` : "0%")}
            {metric("Validated Jobs",audit?.final_valid_count || 0)}
          </div>
          <h3>Strengths</h3>
          {(gap?.candidate_strengths||[]).slice(0,6).map(x=><div key={x.skill} style={{padding:"7px 0"}}>✓ {x.skill} <span style={css.muted}>({x.market_presence}% market presence)</span></div>)}
        </div>

        <div style={css.card}>
          <h2 style={css.h2}>⚠️ Skill Gaps</h2>
          {(gap?.missing_skills||[]).slice(0,8).map(x=><div key={x.skill} style={{borderTop:"1px solid #eee",padding:"10px 0"}}>
            <strong>{x.skill}</strong> <span style={{...css.chip,background:"#fff7ed",color:"#c2410c"}}>{x.importance}</span>
            <div style={css.muted}>{x.recommended_action}</div>
          </div>)}
        </div>
      </div>}

      {tab==="jobs" && profile && <div style={{...css.card,marginTop:18}}>
        <h2 style={css.h2}>💼 Ranked Job Opportunities</h2>
        {jobs.map(job=><div key={job.id} style={css.job}>
          <div style={{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap"}}>
            <div>
              <strong>{job.title}</strong>
              <div style={css.muted}>{job.company} · {job.location} · {job.experience_level}</div>
            </div>
            <div style={{fontWeight:800,color:job.match_score>=70?"#027a48":"#b54708"}}>{job.match_score}% Match</div>
          </div>
          <p style={css.muted}>{job.description}</p>
          <div><strong>Matched:</strong> {(job.matched_skills||[]).join(", ") || "None"}</div>
          <div style={{marginTop:5}}><strong>Missing:</strong> {(job.missing_skills||[]).join(", ") || "None"}</div>
          <a href={job.original_url} target="_blank" rel="noreferrer" style={{display:"inline-block",marginTop:9,color:"#4f46e5",fontWeight:700}}>View application ↗</a>
        </div>)}
      </div>}

      {tab==="graph" && profile && <div style={{marginTop:18}}>
        <div style={css.card}>
          <h2 style={css.h2}>🗺️ Career Graph</h2>
          <p style={css.muted}>Your current skills → target role → missing skills → future career progression.</p>
          <Graph data={graph} />
        </div>
      </div>}

      {tab==="whatif" && profile && <div style={{marginTop:18}}>
        <div style={css.card}>
          <h2 style={css.h2}>🔮 What-if Career Simulation</h2>
          <p style={css.muted}>Ask: “What if I learn Docker?” The system recalculates your career position and opportunities.</p>
          <div style={{display:"flex",gap:8,marginTop:12}}>
            <input style={{...css.input,flex:1}} value={whatIfSkill} onChange={e=>setWhatIfSkill(e.target.value)} placeholder="Docker, AWS, Kubernetes..." />
            <button style={css.primary} onClick={runWhatIf} disabled={whatIfLoading}>{whatIfLoading?"Simulating...":"Simulate"}</button>
          </div>

          {whatIf && <div style={{marginTop:20}}>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
              {metric("Skill Added",whatIf.what_if_skill)}
              {metric("Previous Match",`${whatIf.previous_match_score}%`)}
              {metric("Updated Match",`${whatIf.updated_match_score}%`)}
              {metric("Score Boost",`+${whatIf.score_boost}%`)}
            </div>

            <div style={{marginTop:18,padding:16,background:"#f8fafc",borderRadius:12}}>
              <strong>🚀 Updated Career Graph</strong>
              <Graph data={graph} whatIfData={whatIf} />
            </div>

            <h3>Newly Unlocked Jobs</h3>
            {(whatIf.newly_unlocked_jobs||[]).length===0
              ? <p style={css.muted}>This skill improves your profile, but no new job crossed the 60% threshold.</p>
              : (whatIf.newly_unlocked_jobs||[]).map(j=><div key={j.id} style={css.job}>
                  <strong>{j.title}</strong> · {j.company}
                  <span style={{marginLeft:12,color:"#027a48",fontWeight:800}}>{j.new_match_score}%</span>
                </div>)
            }
          </div>}
        </div>
      </div>}

      {tab==="roadmap" && profile && <div style={{marginTop:18}}>
        <div style={css.card}>
          <h2 style={css.h2}>🧭 Personalized Career Roadmap</h2>
          <p style={css.muted}>{roadmap?.summary}</p>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,margin:"15px 0"}}>
            {metric("Current Match",`${roadmap?.current_match_score || 0}%`)}
            {metric("Projected Match",`${roadmap?.projected_match_score || 0}%`)}
          </div>

          {(roadmap?.phases||[]).map(p=><div key={p.phase_number} style={{borderTop:"1px solid #eaecf0",padding:"18px 0"}}>
            <h3 style={{margin:"0 0 5px"}}>Phase {p.phase_number}: {p.title}</h3>
            <div style={css.muted}>{p.duration}</div>
            <p><strong>Focus:</strong> {(p.focus_skills||[]).join(", ")}</p>
            <p><strong>Objectives:</strong> {(p.learning_objectives||[]).join(" • ")}</p>
            <p><strong>Milestone:</strong> {p.milestone_project}</p>
            {p.recommended_portfolio_project && <div style={{background:"#f8fafc",padding:12,borderRadius:9}}>
              <strong>Portfolio Project: {p.recommended_portfolio_project.title}</strong>
              <div style={css.muted}>{p.recommended_portfolio_project.description}</div>
              <div style={{marginTop:6}}>{(p.recommended_portfolio_project.tech_stack||[]).map(s=><span key={s} style={css.chip}>{s}</span>)}</div>
            </div>}
          </div>)}

          <h3>Interview Preparation</h3>
          {(roadmap?.interview_preparation_tips||[]).map((x,i)=><div key={i} style={{padding:"6px 0"}}>✓ {x}</div>)}
        </div>
      </div>}

      {profile && trending.length>0 && <div style={{...css.card,marginTop:18}}>
        <h2 style={css.h2}>🔥 Trending Technologies</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
          {trending.map(t=><div key={t.name} style={{border:"1px solid #e5e7eb",borderRadius:10,padding:12}}>
            <strong>{t.name}</strong>
            <div style={css.muted}>{t.category}</div>
            <div style={{marginTop:7,fontWeight:800}}>{t.growth_rate}</div>
            <div style={css.muted}>{t.est_learning_time}</div>
          </div>)}
        </div>
      </div>}
    </main>
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);
