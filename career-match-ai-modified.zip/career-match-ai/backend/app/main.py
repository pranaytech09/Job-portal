import os
import re
from typing import Optional

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

APP_NAME = "CareerMatch AI"
APP_VERSION = "2.0.0"
PORT = 8000

app = FastAPI(title=APP_NAME, version=APP_VERSION,
              description="Resume analysis, job matching, career graph, what-if simulation and roadmap.")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000","http://127.0.0.1:3000",
                   "http://localhost:5173","http://127.0.0.1:5173"],
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"]
)

SKILLS = [
    "Python","Java","C++","JavaScript","TypeScript","React","Node.js","Express",
    "HTML","CSS","SQL","MongoDB","PostgreSQL","Git","GitHub","Docker","Kubernetes",
    "AWS","Azure","REST API","FastAPI","Django","Machine Learning","Deep Learning",
    "TensorFlow","PyTorch","Pandas","NumPy","Scikit-learn","Power BI","Data Analysis",
    "Data Structures","Algorithms"
]

ROLE_REQUIREMENTS = {
    "Full Stack Software Engineer": ["Python","JavaScript","React","Node.js","SQL","Git","REST API","Docker"],
    "Frontend Developer": ["HTML","CSS","JavaScript","React","Git","TypeScript"],
    "Backend Developer": ["Python","FastAPI","SQL","REST API","Git","Docker"],
    "AI/ML Engineer": ["Python","Machine Learning","Deep Learning","TensorFlow","Pandas","NumPy","Scikit-learn"],
    "Data Analyst": ["Python","SQL","Pandas","NumPy","Data Analysis","Power BI"]
}

# Demo job catalogue. It is intentionally local so the hackathon demo works
# without Jobvita/Jobspresso/another external job API.
JOBS = [
    {"id":"JOB001","title":"Full Stack Software Engineer","company":"Microsoft","location":"Remote",
     "experience_level":"Entry Level","salary_range":"₹6 - ₹12 LPA","posted_date":"2 days ago",
     "description":"Build scalable full-stack web applications.",
     "skills":["Python","JavaScript","React","Node.js","SQL","Git","REST API","Docker"],
     "original_url":"https://careers.microsoft.com/"},
    {"id":"JOB002","title":"Software Engineer","company":"Accenture","location":"Hyderabad",
     "experience_level":"Entry Level","salary_range":"₹5 - ₹9 LPA","posted_date":"3 days ago",
     "description":"Develop enterprise software applications.",
     "skills":["Python","Java","SQL","Git","REST API"],
     "original_url":"https://www.accenture.com/"},
    {"id":"JOB003","title":"Frontend Developer","company":"Google","location":"Bangalore",
     "experience_level":"Entry Level","salary_range":"₹8 - ₹15 LPA","posted_date":"1 day ago",
     "description":"Create modern and scalable web experiences.",
     "skills":["HTML","CSS","JavaScript","React","TypeScript","Git"],
     "original_url":"https://careers.google.com/"},
    {"id":"JOB004","title":"AI/ML Engineer","company":"Amazon","location":"Bangalore",
     "experience_level":"Entry Level","salary_range":"₹8 - ₹16 LPA","posted_date":"4 days ago",
     "description":"Build machine learning solutions for large-scale systems.",
     "skills":["Python","Machine Learning","Deep Learning","TensorFlow","Pandas","NumPy","Scikit-learn"],
     "original_url":"https://www.amazon.jobs/"},
    {"id":"JOB005","title":"Backend Developer","company":"Deloitte","location":"Hyderabad",
     "experience_level":"Entry Level","salary_range":"₹6 - ₹11 LPA","posted_date":"5 days ago",
     "description":"Develop APIs and backend services.",
     "skills":["Python","FastAPI","SQL","REST API","Git","Docker"],
     "original_url":"https://www.deloitte.com/"}
]

SAMPLE_RESUMES = [
    {"id":"resume_1","name":"Full Stack Developer","skills":["Python","JavaScript","React","Node.js","SQL","Git"],"experience":1},
    {"id":"resume_2","name":"AI/ML Developer","skills":["Python","Machine Learning","TensorFlow","Pandas","NumPy","SQL"],"experience":1},
    {"id":"resume_3","name":"Software Engineer","skills":["Python","Java","SQL","Git","REST API","Docker"],"experience":2}
]

def norm(x): return str(x).lower().strip()

def find_skills(text):
    found=[]
    low=norm(text)
    for skill in SKILLS:
        if re.search(r"(?<!\w)"+re.escape(skill.lower())+r"(?!\w)", low):
            found.append(skill)
    return list(dict.fromkeys(found))

def extract_name(text):
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    if lines and len(lines[0].split())<=5:
        return lines[0]
    return "Candidate"

def extract_experience(text):
    m=re.search(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)", text.lower())
    return float(m.group(1)) if m else 0

def extract_education(text):
    low=text.lower()
    keys=["B.Tech","B.E","BTech","Bachelor","M.Tech","M.E","Master","Computer Science","Engineering"]
    found=[k for k in keys if k.lower() in low]
    return list(dict.fromkeys(found)) or ["Computer Science / Engineering"]

def match_score(candidate, required):
    cs={norm(x) for x in candidate}
    matched=[x for x in required if norm(x) in cs]
    missing=[x for x in required if norm(x) not in cs]
    score=round(len(matched)/len(required)*100) if required else 0
    level="Excellent Match" if score>=80 else "Strong Match" if score>=60 else "Moderate Match" if score>=40 else "Low Match"
    return score,level,matched,missing

def career_graph(skills, target):
    req=ROLE_REQUIREMENTS.get(target,ROLE_REQUIREMENTS["Full Stack Software Engineer"])
    nodes=[{"id":"candidate","label":"Your Profile","type":"candidate"}]
    edges=[]
    skill_ids=[]
    for i,s in enumerate(skills):
        sid=f"skill_{i}"; skill_ids.append(sid)
        nodes.append({"id":sid,"label":s,"type":"skill"}); edges.append({"source":"candidate","target":sid})
    nodes.append({"id":"target","label":target,"type":"career"})
    sset={norm(s) for s in skills}
    for i,s in enumerate(skills):
        if norm(s) in {norm(x) for x in req}: edges.append({"source":skill_ids[i],"target":"target"})
    missing=[s for s in req if norm(s) not in sset]
    for i,s in enumerate(missing):
        mid=f"missing_{i}"; nodes.append({"id":mid,"label":s,"type":"missing"}); edges.append({"source":mid,"target":"target"})
    for i,r in enumerate(["Senior Software Engineer","Technical Lead","Solution Architect"]):
        fid=f"future_{i}"; nodes.append({"id":fid,"label":r,"type":"future"}); edges.append({"source":"target","target":fid})
    return {"nodes":nodes,"edges":edges,"target_role":target,"missing_skills":missing}

def trending():
    return [
        {"name":"Docker","category":"Cloud & DevOps","growth_rate":"+38%","market_demand":"High","strategic_reason":"Improves deployment and backend opportunities.","learning_difficulty":"Medium","est_learning_time":"2-3 weeks"},
        {"name":"React","category":"Frontend","growth_rate":"+31%","market_demand":"Very High","strategic_reason":"Widely used for modern web applications.","learning_difficulty":"Medium","est_learning_time":"3-4 weeks"},
        {"name":"FastAPI","category":"Backend","growth_rate":"+29%","market_demand":"High","strategic_reason":"Excellent Python framework for APIs and AI applications.","learning_difficulty":"Easy","est_learning_time":"1-2 weeks"},
        {"name":"Machine Learning","category":"Artificial Intelligence","growth_rate":"+42%","market_demand":"Very High","strategic_reason":"Strong demand across AI-driven products.","learning_difficulty":"Hard","est_learning_time":"6-10 weeks"}
    ]

def skill_gap(skills):
    cs={norm(s) for s in skills}
    freq={}
    for job in JOBS:
        for s in job["skills"]: freq[norm(s)]=freq.get(norm(s),0)+1
    strengths=[]; missing=[]
    for key,count in freq.items():
        original=next((s for s in SKILLS if norm(s)==key),key.title())
        demand=round(count/len(JOBS)*100)
        if key in cs: strengths.append({"skill":original,"market_presence":demand})
        elif demand>=40:
            missing.append({"skill":original,"importance":"High" if demand>=70 else "Medium",
                            "recommended_action":f"Learn {original} and build a practical project using it.",
                            "demand_percentage":demand})
    total=sum(freq.values())
    matched=sum(v for k,v in freq.items() if k in cs)
    readiness=round(matched/total*100) if total else 0
    return {"market_readiness_index":readiness,"total_analyzed_jobs":len(JOBS),
            "candidate_strengths":strengths,"missing_skills":missing,"critical_gaps_count":len(missing)}

def roadmap(skills,target,current):
    req=ROLE_REQUIREMENTS.get(target,ROLE_REQUIREMENTS["Full Stack Software Engineer"])
    missing=[s for s in req if norm(s) not in {norm(x) for x in skills}]
    phases=[]
    if missing:
        focus=missing[:3]
        phases.append({"phase_number":1,"title":"Close Your Core Skill Gaps","duration":"2-4 weeks",
                       "focus_skills":focus,"learning_objectives":[f"Understand {x}" for x in focus],
                       "practical_activities":["Follow hands-on tutorials","Build small coding exercises","Practice interview questions"],
                       "milestone_project":f"Build a mini project using {focus[0]}",
                       "recommended_portfolio_project":{"title":"Skill Gap Demonstration Project",
                       "description":"A practical project demonstrating your missing skills.","tech_stack":focus,
                       "key_features":["Authentication","REST API","Database","Responsive UI"]}})
    phases.append({"phase_number":len(phases)+1,"title":"Build a Strong Portfolio Project","duration":"3-5 weeks",
                   "focus_skills":req,"learning_objectives":["Apply skills in a real project","Understand project architecture","Write clean code"],
                   "practical_activities":["Design","Develop frontend and backend","Connect APIs/database","Deploy"],
                   "milestone_project":"Complete and deploy a full-stack project",
                   "recommended_portfolio_project":{"title":"AI Career Intelligence Platform",
                   "description":"Analyze resumes, match jobs and create personalized career paths.",
                   "tech_stack":["Python","FastAPI","React","SQL","AI"],
                   "key_features":["Resume analysis","Job matching","Career graph","What-if simulation","Career roadmap"]}})
    phases.append({"phase_number":len(phases)+1,"title":"Placement Preparation","duration":"3-4 weeks",
                   "focus_skills":["Data Structures","Algorithms","SQL","System Design"],
                   "learning_objectives":["Improve problem solving","Prepare for coding rounds","Prepare for interviews"],
                   "practical_activities":["Solve coding problems","Practice SQL","Take mock interviews","Improve resume"],
                   "milestone_project":"Complete placement preparation checklist",
                   "recommended_portfolio_project":{"title":"Interview Ready Portfolio","description":"Polish projects and prepare interview explanations.",
                   "tech_stack":req,"key_features":["GitHub portfolio","Documentation","Resume optimization","Mock interviews"]}})
    projected=min(98,current+max(15,len(missing)*5))
    return {"summary":f"Personalized roadmap for becoming a {target}.","score_boost":projected-current,
            "current_match_score":current,"projected_match_score":projected,"phases":phases,
            "interview_preparation_tips":["Explain every project on your resume.","Practice DSA and SQL regularly.","Prepare STAR-format behavioral answers.","Know the fundamentals of your main technologies."]}

async def resume_text(file):
    if not file: return ""
    data=await file.read(); name=(file.filename or "").lower()
    if name.endswith(".txt"): return data.decode("utf-8",errors="ignore")
    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
            import io
            return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(data)).pages)
        except Exception: return ""
    if name.endswith(".docx"):
        try:
            from docx import Document
            import io
            return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
        except Exception: return ""
    return data.decode("utf-8",errors="ignore")

def default_resume():
    return "Software Engineer\nPython JavaScript React Node.js SQL Git REST API\nB.Tech Computer Science\n1 year experience"

@app.get("/api/jobs/sample-resumes")
def sample_resumes(): return {"success":True,"resumes":SAMPLE_RESUMES}

@app.post("/api/career/pipeline")
async def pipeline(resume:Optional[UploadFile]=File(None), target_role:str=Form("Full Stack Software Engineer"),
                   location:str=Form("Remote"), sources:str=Form("")):
    text=await resume_text(resume)
    if not text: text=default_resume()
    skills=find_skills(text) or ["Python","JavaScript","SQL","Git"]
    ranked=[]
    for j in JOBS:
        score,level,matched,missing=match_score(skills,j["skills"])
        ranked.append({**j,"source":"CareerMatch Demo","match_score":score,"match_level":level,
                       "matched_skills":matched,"missing_skills":missing})
    ranked.sort(key=lambda x:x["match_score"],reverse=True)
    req=ROLE_REQUIREMENTS.get(target_role,ROLE_REQUIREMENTS["Full Stack Software Engineer"])
    current,_,_,_=match_score(skills,req)
    return {"success":True,
            "candidate_profile":{"name":extract_name(text),"years_of_experience":extract_experience(text),
            "education":extract_education(text),"skills":skills,"target_role":target_role,"location":location},
            "validation_audit":{"initial_count":len(JOBS),"invalid_urls_removed_count":0,"expired_removed_count":0,
            "duplicates_removed_count":0,"final_valid_count":len(JOBS)},
            "ranked_jobs":ranked,"skill_gap_analysis":skill_gap(skills),
            "trending_technologies":trending(),"career_graph":career_graph(skills,target_role),
            "career_roadmap":roadmap(skills,target_role,current)}

@app.post("/api/career/what-if")
async def what_if(resume:Optional[UploadFile]=File(None), target_role:str=Form("Full Stack Software Engineer"),
                  new_skill:str=Form("Docker")):
    text=await resume_text(resume) or default_resume()
    skills=find_skills(text) or ["Python","JavaScript","SQL","Git"]
    old,_,_,_=match_score(skills,ROLE_REQUIREMENTS.get(target_role,ROLE_REQUIREMENTS["Full Stack Software Engineer"]))
    updated=list(skills)
    if not any(norm(x)==norm(new_skill) for x in updated): updated.append(new_skill)
    new,_,_,_=match_score(updated,ROLE_REQUIREMENTS.get(target_role,ROLE_REQUIREMENTS["Full Stack Software Engineer"]))
    unlocked=[]
    for j in JOBS:
        a,_,_,_=match_score(skills,j["skills"]); b,_,_,_=match_score(updated,j["skills"])
        if a<60 and b>=60: unlocked.append({"id":j["id"],"title":j["title"],"company":j["company"],"new_match_score":b})
    return {"success":True,"what_if_skill":new_skill,"previous_skills":skills,"updated_skills":updated,
            "previous_match_score":old,"updated_match_score":new,"score_boost":new-old,
            "newly_unlocked_jobs":unlocked,"updated_career_graph":career_graph(updated,target_role)}

@app.get("/health")
def health(): return {"status":"healthy","version":APP_VERSION,"message":"CareerMatch AI backend is running"}

@app.get("/api-test")
def api_test(): return {"success":True,"message":"Frontend can successfully connect to FastAPI"}

FRONTEND_DIR=os.path.abspath(os.path.join(os.path.dirname(__file__),"..","..","frontend"))
if os.path.exists(FRONTEND_DIR):
    @app.get("/")
    def root():
        f=os.path.join(FRONTEND_DIR,"index.html")
        return FileResponse(f) if os.path.exists(f) else {"system":APP_NAME,"status":"Online","documentation":"/docs"}

if __name__=="__main__":
    import uvicorn
    uvicorn.run("app.main:app",host="127.0.0.1",port=PORT,reload=True)
